//
//  Products+CoreDataProperties.swift
//  A2_FA_ios_harmander_797040
//
//  Created by jimmy on 01/02/21.
//  Copyright © 2021 jimmy. All rights reserved.
//
//

import Foundation
import CoreData


extension Products {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Products> {
        return NSFetchRequest<Products>(entityName: "Products")
    }

       @NSManaged public var prodID: Int16
       @NSManaged public var prodName: String?
       @NSManaged public var prodDesc: String?
       @NSManaged public var prodPrice: Float
       @NSManaged public var prodProvider: String?

}
