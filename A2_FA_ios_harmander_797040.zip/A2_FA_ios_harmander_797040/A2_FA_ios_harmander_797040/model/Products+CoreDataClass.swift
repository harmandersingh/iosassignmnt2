//
//  Products+CoreDataClass.swift
//  A2_FA_ios_harmander_797040
//
//  Created by jimmy on 01/02/21.
//  Copyright © 2021 jimmy. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Products)
public class Products: NSManagedObject {

}
