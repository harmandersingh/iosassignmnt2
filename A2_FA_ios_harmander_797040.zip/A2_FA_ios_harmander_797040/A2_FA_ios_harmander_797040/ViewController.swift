//
//  ViewController.swift
//  A2_FA_ios_harmander_797040
//
//  Created by jimmy on 01/02/21.
//  Copyright © 2021 jimmy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        @IBOutlet weak var segment: UISegmentedControl!
            @IBOutlet weak var search: UISearchBar!
            var prod: [Product] = []
            var button1 : UIBarButtonItem!
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            var providerNames = [String]()
            var provWithProduct = [String?:[Product]]()
        //    var ExpandedSection = [Int]()
            var ExpandedSection : Int?
            
            
            
            @IBOutlet weak var tblView: UITableView!
            override func viewDidLoad() {
                super.viewDidLoad()
                button1 = UIBarButtonItem(title: "Add", style: .done, target: self, action: #selector(addTapped))
                manageBarButton()
                
                
                self.tblView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
                self.tblView.register(UITableViewHeaderFooterView.self, forHeaderFooterViewReuseIdentifier: "Header")
                self.tblView.register(UITableViewCell.self, forCellReuseIdentifier: "HeaderCEll")
                self.tblView.register(UINib(nibName: "ProviderTVC", bundle: nil), forCellReuseIdentifier: "ProviderTVC")
                // Do any additional setup after loading the view.
            }

            
            @objc func addTapped() {
                let vc : Add_Update_ProductVC = (self.storyboard?.instantiateViewController(identifier: "Add_Update_ProductVC"))!
                vc.mode = .add
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
            override func viewWillAppear(_ animated: Bool) {
              super.viewWillAppear(animated)
                retriveData()
        //        retriveProviders()

            }
            @IBAction func segmentChanged(_ sender: Any) {
                manageBarButton()
                self.tblView.reloadData()
            }
            
            func manageBarButton() {
                if segment.selectedSegmentIndex == 0{
                    self.navigationItem.rightBarButtonItem  = button1
                    self.search.isHidden = false
                }
                else{
                    self.search.isHidden = true
                    self.navigationItem.rightBarButtonItem  = nil
                }
            }
            func retriveProviders() {
                
                let dictionary = Dictionary(grouping: prod, by: { $0.prodProvider })

                print("Dict", dictionary)
                
                let arr = Array(dictionary.keys)
                print("arr", arr)
                
                self.providerNames = arr as! [String]
                
                self.provWithProduct = dictionary
                self.tblView.reloadData()
        //
        //        let newDictionary = dictionary.mapValues { (value: [Product]) in
        //            return value.count
        //        }
        //
        //        print(newDictionary)
                
        //        // 1. Set the column name you want distinct values for
        //        let column = "prodProvider"
        //
        //        // 2. Get the NSManagedObjectContext, for example:
        //        let moc = appDelegate.persistentContainer.viewContext
        //
        //        // 3. Create the request for your entity
        //        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        //
        //        // 4. Use the only result type allowed for getting distinct values
        //        request.resultType = .dictionaryResultType
        //
        //        // 5. Set that you want distinct results
        ////        request.returnsDistinctResults = true
        //
        //        // 6. Set the column you want to fetch
        //        request.propertiesToFetch = [column]
        //
        //        // 7. Execute the request. You'll get an array of dictionaries with the column
        //        // as the name and the distinct value as the value
        //        if let res = try? moc.fetch(request) as? [[String: String]] {
        //            print("res: \(res)")
        //
        //            // 8. Erextract the distinct values
        //            let distinctValues = res.compactMap { $0[column] }
        //
        //            var counts: [String: Int] = [:]
        //
        //            for item in distinctValues {
        //                counts[item] = (counts[item] ?? 0) + 1
        //            }
        //
        //            print(counts)  // "[BAR: 1, FOOBAR: 1, FOO: 2]"
        //
        //
        //
        //        }
            }
            func retriveData() {
                
                let managedContext = appDelegate.persistentContainer.viewContext
                let req: NSFetchRequest<Product> = Product.fetchRequest()
                  
                if search.text?.count ?? 0 > 0{
                        req.predicate = NSPredicate(format: "prodName contains[cd] %@ OR prodDesc contains[cd] %@", search.text ?? "", search.text ?? "")
                }


                do {
                  prod = try managedContext.fetch(req)
                    self.retriveProviders()
                  self.tblView.reloadData()
                } catch let error as NSError {
                  print("Could not fetch. \(error), \(error.userInfo)")
                }
            }

            
        }

        // MARK: - UISearchBarDelegate
        extension ViewController: UISearchBarDelegate {
            func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
                self.view.endEditing(true)
                
            }
            func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
                self.retriveData()
            }
            
        }

        // MARK: - UITableViewDataSource
        extension ViewController: UITableViewDataSource,UITableViewDelegate {
            func numberOfSections(in tableView: UITableView) -> Int {
        //        return 1
                if segment.selectedSegmentIndex == 0{
                    return 1
                }
                return providerNames.count
            }
            
            func tableView(_ tableView: UITableView,
                           numberOfRowsInSection section: Int) -> Int {
                if segment.selectedSegmentIndex == 0{
                    return prod.count
                    
                }else{
                    let provider = providerNames[section]
                    let rows = ExpandedSection == section ? provWithProduct[provider]?.count ?? 0 : 0
                    return (rows + 1)
                }
            }
            
            func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
                if segment.selectedSegmentIndex == 0{
                    return nil
                }
                let provider = providerNames[section]
                
                let view = UIView()
                
                let title = UILabel(frame: CGRect(x: 10, y: 5, width: tableView.frame.size.width, height: 30))
                title.text = provider
                title.font = UIFont.boldSystemFont(ofSize: 15)
                view.addSubview(title)
                
                let subTitle = UILabel(frame: CGRect(x: 10, y: 30, width: tableView.frame.size.width, height: 30))
                subTitle.text = "\(provWithProduct[provider]?.count ?? 0) Products"
                subTitle.font = UIFont.systemFont(ofSize: 13)
                view.addSubview(subTitle)
                
                let seperator = UILabel(frame: CGRect(x: 0, y: 70, width: tableView.frame.size.width, height: 1))
                seperator.backgroundColor = .lightGray
                view.addSubview(seperator)
                return view
            }
            
            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                if segment.selectedSegmentIndex == 0{
                    let product = prod[indexPath.row]

                    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
                    cell.accessoryType = UITableViewCell.AccessoryType.none
                    cell.textLabel?.text = product.prodName ?? ""
                    cell.accessoryType = .disclosureIndicator
                    cell.selectionStyle = .none
                    return cell
                }
                else{
                    let provider = providerNames[indexPath.section]
                    
                    
                    if indexPath.row == 0{
                        
                        let cell = tableView.dequeueReusableCell(withIdentifier: "ProviderTVC", for: indexPath) as? ProviderTVC
                        cell?.lbTitle.text = provider
                        cell?.lbSubtitle.text = "\(provWithProduct[provider]?.count ?? 0) Products"
                        return cell!
                    }
                    let product = provWithProduct[provider]?[indexPath.row-1]
                    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
                    cell.accessoryType = UITableViewCell.AccessoryType.none
                    cell.textLabel?.text = product?.prodName ?? ""
                    cell.accessoryType = .disclosureIndicator
                    cell.selectionStyle = .none
                    return cell
                }
                
            }
            func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
                return 0
            }
            func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                if segment.selectedSegmentIndex == 0{
                    let product = prod[indexPath.row]
                    let vc : ProductDetailVC = self.storyboard?.instantiateViewController(identifier: "ProductDetailVC") as! ProductDetailVC
                    vc.prod = product
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                else{
                    if indexPath.row == 0{
                        ExpandedSection = indexPath.section
                        self.tblView.reloadData()
                    }else{
                        let provider = providerNames[indexPath.section]
                        let product = provWithProduct[provider]?[indexPath.row-1]
                        let vc : ProductDetailVC = self.storyboard?.instantiateViewController(identifier: "ProductDetailVC") as! ProductDetailVC
                        vc.prod = product
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                    
                }
                
            }
            func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
                if segment.selectedSegmentIndex == 0
                {
                return true
                }
                return false
            }
            
            func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
                
                if editingStyle == .delete {
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    let viewContext = appDelegate.persistentContainer.viewContext
                    
                    viewContext.delete(prod[indexPath.row])
                    
                    do {
                        try viewContext.save()
                        print("Deleting Done")
                        self.prod.remove(at: indexPath.row)
                        self.tblView.reloadData()
                       }
                    catch {
                        print("Saving Failed: \(error)")
                    }
                    
                }
                
            }
       }
    }



